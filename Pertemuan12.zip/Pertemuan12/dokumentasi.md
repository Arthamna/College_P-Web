# Latihan CRUD Foto 
## Alur Kerja 
- Index => Entry Point, memuat seluruh data dari database
- Panggil form_simpan.php jika ingin simpan, dan form_ubah.php jika ingin mengubah data yang ada
- Setiap fungsi terkait akan membawa ke proses_simpan.php dan proses_ubah.php


## Tampilan Awal
![](/Pertemuan12/imgs/tambah.png)

## Tambah data
![](/Pertemuan12/imgs/image.png)

## Ubah data
(disini ubah nama dan nis)
![](/Pertemuan12/imgs/ubah.png)


## Hapus data
![](/Pertemuan12/imgs/tambah.png)